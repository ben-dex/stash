
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.JavaRDD;

import java.util.Map;

public class MaxTemperature {

    public static void main(String[] args) {

        // Configure Spark
        SparkConf conf = new SparkConf()
                .setAppName("Maximum Temperature")
                .setMaster("local[*]");

        // Create Spark Context
        JavaSparkContext sc = new JavaSparkContext(conf);

        // Read input file
        JavaRDD<String> data =
                sc.textFile("temperature.txt");

        // Convert each line into city and temperature
        JavaRDD<Map.Entry<String, Integer>> temperatures =
                data.map(line -> {
                    String[] parts = line.split(",");
                    return new java.util.AbstractMap.SimpleEntry<>(
                            parts[0],
                            Integer.parseInt(parts[1])
                    );
                });

        // Find maximum temperature record
        Map.Entry<String, Integer> maxTemperature =
                temperatures.reduce((a, b) ->
                        a.getValue() > b.getValue() ? a : b
                );

        // Display result
        System.out.println("City: " +
                maxTemperature.getKey());

        System.out.println("Maximum Temperature: " +
                maxTemperature.getValue());

        // Stop Spark
        sc.close();
    }
}
