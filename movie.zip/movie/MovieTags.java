import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MovieTags {

    public static class TagMapper
            extends Mapper<Object, Text, Text, Text> {

        private Text movieId = new Text();
        private Text tag = new Text();

        public void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {

            String line = value.toString();

            // Skip header
            if (line.startsWith("userId")) {
                return;
            }

            String[] fields = line.split(",", 4);

            if (fields.length == 4) {
                movieId.set(fields[1]);
                tag.set(fields[2]);

                context.write(movieId, tag);
            }
        }
    }

    public static class TagReducer
            extends Reducer<Text, Text, Text, Text> {

        public void reduce(Text key, Iterable<Text> values,
                            Context context)
                throws IOException, InterruptedException {

            StringBuilder tags = new StringBuilder();

            for (Text value : values) {

                if (tags.length() > 0) {
                    tags.append(",");
                }

                tags.append(value.toString());
            }

            context.write(key, new Text(tags.toString()));
        }
    }

    public static void main(String[] args)
            throws Exception {

        Configuration conf = new Configuration();

        Job job = Job.getInstance(conf, "Movie Tags");

        job.setJarByClass(MovieTags.class);

        job.setMapperClass(TagMapper.class);
        job.setReducerClass(TagReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(
                job,
                new Path(args[0])
        );

        FileOutputFormat.setOutputPath(
                job,
                new Path(args[1])
        );

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
